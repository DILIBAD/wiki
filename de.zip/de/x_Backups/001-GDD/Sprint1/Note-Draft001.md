---
title: Draft 001
description: 
published: true
date: 2025-04-28T11:40:59.388Z
tags: 
editor: markdown
dateCreated: 2025-04-25T14:18:24.937Z
---

Notes Popup Treffen 25.04:


Charakter General:
- Movement ( WASD)


Charakter Stats:
- Health
- Damage
- Defense
- Attack Speed => nur für Auto Attack?
- Movement Speed
- Abbaugeschwindigkeit

Klasse => Spezialisierung  (Fixed)
- Sammler
- Kämpfer
- ....


Inventar:
 - Maximale Tragemenge an Kristallen
 
 Items:
 - Kristall
 - Hinweise


Kampfart 

Nahkampf (Schwert)
- Auto Attack (Attack Speed)
- Schwerer Angriff (Skill CD)
- Rundumschlag (Skill CD)
- Jump Attack (Skill CD)

Fernkampf (Bogen)
 - Auto Attack (Attack Speed)
 - Geladener Schuss (Skill CD)
 - Aoe Abbility (Pfeilhagel)  (Skill CD)
 - Dodge Backward with Arrow in your knee (Skill CD)



Upgrades Charakter:
3 Upgrades

Passive Upgrades:
1. Attack
2. Defense
3. Sammler: Schneller abbauen | Fighter: Attack Speed   

Abbauen von Rohstoffen und Interagieren mit Gebäuden mit Interaktion Key near by

---
Boss & Monster
Angriffsmuster Boss:
- Base Attack
- Heavy Attack (CD)
- AOE (CD)
- Knockback (CD)




---
Wellen
Die Angriffswellen die durch volles Gefahrenlevel ausgelöst wird, werden mit jeder Welle um einen festgelegten Wert. 

Optionen für "stärker":
=> stärkere monster
=> Mehr Monster

---
Gefahrenlevel

Das Gefahrenlevel gibt an wann die nächste Angriffswelle auf die Basis ansteht.

Durch folgende Aktionen des Spielers wächst das Gefahrenlevel:
- Durch das abbauen von Rohstoffen
- Durch das töten von Monstern

TBD:
Zusätzlich wächst das Gefahrenlevel mit einem fixen Wert kontinuierlich. LATER => Diese zunahme wird für Schwierigkeitsgrade genutzt. Je höher der Schwierigkeitsgrad desto höher die Zunahme im Idle.

Der genaue Wert der Gefahrenzunahme ist von Balancefaktoren abhängig und muss somit während der Entwicklung durchs Tests bestimmt werden.

---

Basis
Rohstoffe werden zur Basis gebracht und können dort für Char Upgrades ausgegeben werden oder an Gebäudeslots genutzt werden, um diese zu bauen oder aufzuwerten.


Walls und Türme
- Upgrades Walls => Leben
- Upgrades Türme => Leben und Angriffsschaden und Attackspeed


Spieler sollen Monster nicht abusive kiten können
Aggro Level => simple Enmity System
> Enmity am Beispiel von [Final Fantasy](https://ffxiv.consolegameswiki.com/wiki/Enmity)

----
Max Level pro Upgrade
  => Basierend auf Balancing

=> Main Waffe? => Equipment bestimmt wie du kämpfst => (wechselbar)
Upgrade:
- Mehrere Upgrades mit Elementen welche kombiniert werden können
- Passive Dodge  
- Healer hoher impact auf gain für die gruppe
- Inteliigent
- Level
-  Dodge ( any key to dodge) 

-------------
UI – Designentscheidungen DILIBAD Sprint 1

Bei der Findung und Validierung der anfänglichen UI-Elemente im Projekt DILIBAD wurde sich an den gängigen Spielen der Genres Aufbau und Rollenspiel (RPG) orientiert.

Für die Ansicht, die der Spieler nach dem Öffnen des Spiels zu Gesicht bekommt, hat man sich für eine Begrüßung des Spielers inklusive dem Spielnamen „DILIBAD“ und einem Hauptmenü mit folgenden Unterpunkten entschieden: „Neues Spiel“, „Spiel laden“, „Einstellungen“ und „Spiel verlassen“.

Über das Menü, das der Spieler während des Spielens aufrufen kann, sollten die Funktionen „Speichern“, „Upgrades“, „Graphics“-, „Lautstärkeeinstellungen“ und „Spiel verlassen“ aufrufbar sein.

Als essenziell für die grundlegende Spielansicht für den Benutzer haben sich die UI-Elemente „Lebenspunkte“, „Schlüsselkristalle im Inventar“, „globale Anzahl der Schlüsselkristalle im Teambesitzt“, „Anzahl der Hauptkristalle im Inventar mit Tragekapazität“ und „Miniaturansicht der Karte“ mit anliegender „Enmity-Anzeige“ herausgestellt.

Des Weiteren hat man sich für das Implementieren einer „Fähigkeitenleiste“ mit Tastenkürzeln für die Fähigkeiten des Charakters sowie den Knopf zum Öffnen des Einstellungsmenüs.

Im weiteren Vorgehen werden die Funktionen auf ihre Benutzerfreundlichkeit getestet und abhängig von den Ergebnissen erweitert, verändert oder entfernt.

