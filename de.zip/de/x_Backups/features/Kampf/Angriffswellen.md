---
title: Angriffswellen
description: 
published: true
date: 2025-04-18T20:15:28.450Z
tags: 
editor: markdown
dateCreated: 2025-04-18T20:15:28.450Z
---

# Angriffswellen
Angriffswellen sind Event welche im Spiel ausgelöst werden und in Assoziation mit der Basis stehen. Hierbei werden Gegnerische Einheiten gespawned welche die Basis angreifen wollen. Der Spieler muss mithilfe seiner Verteidigungsgeäuden und eigener Kampfkraft die Feindlichen Angriff zurückschlagen.

Zu Gewährleistung abwechslungsreicher Angriffswellen sollen Unterschiedliche herangehensweisen zur Bekämpfung genutzt werden.

## Auslöser
Die Angriffswellen werden durch Spieleraktionen ausgelöst. Der Spieler erhält über ein einheitliches System rückmeldung darüber wie nah die nächste Welle ist. Der Auslöser könnte durch eine Loreaspekt untermalt/designed werden. 

Simpleste Implementierung würde ein Slider sein der sich durch bestimmte Aktionen, bspw. Abbauen von Rohstoffen oder töten von Gegnerischen Einheiten (aka Aggro ziehen der Welle) immer weiter auflädt. Der Spieler sollte wenn die Welle kommt eine kurze Vorbereitungszeit haben, um rechtzeitig zur Basis zurückkehren zu können.


## Klassiches Aushalten
Die simpelste Form ist das Angriffswellen ausharren. Hier muss der Spieler eine bestimmte Anzahl an Wellen überstehen bevor die Angriffswellen nachlassen und die Basis sicher ist.

## Bekämpfen von Portalen
Der Spieler muss neben dem Verteidigen die Portale zerstören durch welche die Gegner kommen. Hierbei müssen die Spieler ein gleichgewicht zwischen Verteidigung und Angriff finden.

## Ritual durchführen
Die Spieler müssen Gegenstände die durch Gegner fallen gelassen werden, auf eine bestimmte weise nutzen um ein Ritual durchzuführen welche die Gegner verscheucht.

