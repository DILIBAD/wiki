---
title: Basis
description: 
published: true
date: 2025-04-18T20:00:17.818Z
tags: 
editor: markdown
dateCreated: 2025-04-18T19:47:17.126Z
---

# Basiskonzept

Die Basis dient als Produktions und Rückzugsort für den Spieler. Die Basis wird durch Rohstoffe durch den Spieler aufgewertet. Der Spieler kann Verteidigungsstrukturen errichten, damit diese besser vor Angriffswellen verteidigt wird. 

## Basisbau
Der Spieler kann zwischen vorgewählten Baubaren Gebäuden wählen. Zum Bau müssen in die Basis gebracht werden.

## Verteidigungsstrukturen
Vereidigungsstukturen werden durch NPCs in Betrieb genommen und verteidigen die Basis vor Angriffswellen. 

## Bevölkerung
NPCs können sich in der Basis ansiedeln und stellen dem Spieler ihre Dienstleistungen zur Verfügung. Neben Verteidigungsaufgaben, können diese auch Rohstoffe vererdeln und Produktionen durchführen.

## Veredelungsgebäude 
Diese Gebäude werden genutzt um Rohstoffe zu verarbeiten, damit bessere Gegenstände produziert werden können.


## Produktionsgebäude
Diese Gebäude können Bestellungen von Spielern aufnehmen. NPCs fertigen diese Aufträge an sofern die nötigen Rohstoffe vorhanden sind.