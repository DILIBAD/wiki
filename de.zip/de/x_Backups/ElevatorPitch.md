---
title: Elevator Pitch
description: 
published: true
date: 2025-04-17T21:48:24.752Z
tags: 
editor: markdown
dateCreated: 2025-04-17T21:48:18.654Z
---

In unserem einzigartigen Mix aus Tower Defense, Action-RPG und Ressourcenmanagement schlüpft der Spieler in die Rolle eines “Befreiers”. In einer von Fantasy geprägten Welt gilt es, feindlich besetzte Gebiete zu erkunden, wertvolle Rohstoffe zu fördern und eine eigene Basis auszubauen. Doch jede Ressourcengewinnung ruft neue Gegnerwellen hervor. Taktisches Bauen, Kämpfen und Aufrüsten sind entscheidend. Ziel ist es, Hinweise zu sammeln, den Weg zum Boss-Monster zu finden und das Gebiet endgültig zu befreien. Wer den Boss besiegt, meistert die Herausforderung und schließt das Spiel erfolgreich ab.