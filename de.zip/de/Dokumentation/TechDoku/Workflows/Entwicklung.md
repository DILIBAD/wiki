---
title: Entwicklung
description: 
published: true
date: 2025-04-20T09:50:27.543Z
tags: 
editor: markdown
dateCreated: 2025-04-20T09:50:27.543Z
---

# Entwicklungs Workflow


In Sprint 1 werden Tests nur Intern durchgeführt oder mit kleinen ausgewählten Testgruppen. Hier wird noch nicht die Community genutzt da die Version unkontrollierte Testgruppen noch nicht unterstützt.



Am Ende von Sprint 1 existiert eine Spielbare Version mit einem festen Server auf dem das Spiel laufen wird. Max Spieler 4-8 TBD. Der Server wird bei einem Game Over oder Win die session nach einer kurzen Zeit zurücksetzten und von vorne Starten. Alternativ benötigt es eine Option den Server zurückzusetzen sodass dieser durch Entwickler manuell zurückgesetzt werden kann falls ein Stuck Bug aufgetreten ist. Sodass ein aufschalten mit RDP auf den Server nur selten nötig ist.


In Sprint 2 soll die Spielstruktur so abgeändert werden das mithilfe von 