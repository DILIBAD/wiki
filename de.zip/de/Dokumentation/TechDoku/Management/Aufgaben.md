---
title: Aufgaben
description: 
published: true
date: 2025-05-09T08:37:47.177Z
tags: 
editor: markdown
dateCreated: 2025-05-02T09:06:17.055Z
---

# Zweck des Dokumentes
In diesem Dokument werden alle Aufgaben, die vorhanden sind, übersichtlich festgehalten und dokumentiert.  
Aufgabenfelder, die hinzukommen, werden eingetragen und in einem Meeting wird geprüft, ob eine Zuweisung einer verantwortlichen Person nötig ist oder aufgeschoben werden kann.

## Aufgabenfelder:

| Aufgabe                            | Hauptverantwortlich | Vertretung     |
|------------------------------------|---------------------|----------------|
| GDD |    Nils   |   |
| YouTrack, Konfigurationen & Workflows |       | Nils  |
| Meeting Organisation |         |   |
| Scrum Master |         |  Konstantin |
| GIT |   Konstantin      |   |
| Assets |    Konstantin, Pascal   |   |
| Kommunikation mit Dozenten |    Martin     |   |
| Conflict Manager |    Martin     | Nils  |
| Dokumentaiton |  Konstantin , ??     |   |
| Protokol |     Pascal    |   |


| Sekundäraufgaben                            | Hauptverantwortlich | Vertretung     |
|------------------------------------|---------------------|----------------|
| CI/CD       | Konstantin         |   |
| Music & Sounds |   Martin    |   |
| Social Media |    Dimar     |   |
| Webseite |    Konstantin     |   |
| Discord |    Konstantin     |   |
| Infrastruktur |    Konstantin     |   |
| Meeting Organisation |         |   |
| Unity |    Konstantin   |   |
| Music & Sounds |   Martin    |   |
|  |  |  |