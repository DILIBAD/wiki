---
title: Modulmatrix
description: 
published: true
date: 2025-07-05T14:33:57.270Z
tags: 
editor: markdown
dateCreated: 2025-04-28T14:41:29.883Z
---

# Übersicht




# Kompetenzmatrix – Teamübersicht
<br>

| Kompetenzbereich               | Martin | Pascal | Dima | Konstantin | Alex | Nils |
|:--------------------------------|:------:|:------:|:----:|:----------:|:----:|:----:|
| Entwicklung (Programmierung)    |   ✅    |   ✅    | ✅   |     ✅      | ✅   |  ✅    |
| IT-Security & Infrastruktur     |   ✅    |        |     |     ✅      |      |   ✅   |
| Design & Content                |        |   ✅    |     |     ✅      | ✅   |    |
| Management & Softskills         |   ✅    |   ✅    | ✅   |     ✅      | ✅   | ✅     |

<br>
<br>

# Modulmatrix


Diese Matrix zeigt, welche Personen welche Module besucht haben, um schnell einen Überblick über Stärken und Vertiefungen zu erhalten.

<br>


| Modul                                | Martin | Pascal | Dima | Konstantin | Alex|   Nils  
|--------------------------------------|:--------:|:--------:|:--------:|:--------:|:--------:|:--------:|
| Change-Management                    |    X     |          |          |          |          |          |
| Cybersicherheit im Unternehmen       |    X     |          |          |          |          |          |
| Einführung IT-Security               |    X     |         |          |          |          |   X       |
| Entwicklung mobiler Applikationen    |				  | 		X		|         |           |          | 				|
| Gesellschaftliche Verantwortung in der Informatik                  |        |          |         |          |          |  X        |
| Haptische Benutzerschnittstellen                  |        |          |         |          |          |  X        |
| Interaktive Systeme                  |     X    |     X     |    X     |          |          |  X        |
| Diskrete Mathematik                  |     X    |         |          |      X    |          |          |
| Recht für Informatiker/innen         |     X     |         |    X     |     X     |          |          |
| English for STEM 2                   |     X    |          |          |         |          |          |
| Content Management Systeme           |          |          |          |     X     |     X   |          |
| Praktikum Game Design und Development|          |     X     |          |      X    |    X    |         X |
| Digitale Fotografie und Desktop-Publishing |     |     X     |          |         |      X   |          |
| Digitales Marketing                   |         |          |    X      |          |          |      |
| Texten fürs Web                      |          |          |     X     |    X      |     X    |         |
| Ethik im Management                  |          |          |          |         |      X   |          |
| Lern- und Prüfungsstressbewältigung  |          |          |          |          |         |          |
| Konzepte moderner Softwareentwicklung|          |          |          |     X     |    X    |          |
| Rechnernetze und Einführung in verteilte Systeme |     |          |         |     X     |              |    |
| Webbasierte Systeme 2                |    X      |          |    X      |     X     |    X   |  X        |
| Algorithmen und Datenstrukturen      |    X     |    X    |    X      |     X     |     X    | X         |
| Datenbanksysteme                     |    X     |     X     |          |     X     |    X     |  X        |
| Programmierung interaktiver Systeme  |          |         |          |      X    |          |          |
| Konzepte systenaher Programmierung   |          |          |          |				X  | 				 |        |
| Statistik und Datenanalyse           |          |    X    |          |          |          |          |
| Social Media in der Unternehmensstrategie |          |         |     X     |          |          |          |
| Visuelle Kommunikation               |          |    X     |          |          |          |          |
| Objektorientierte Programmierung     |     X     |    X     |    X      |          |     X    |  X        |
| Zeitmanagement                       |          |    X     |          |          |          |          |
| Digitalwissenschaften - geisteswissenschaftlich gedacht                      |          |        |       X   |          |          |          |
Naturwissenschaftliche und technische Grundlagen                    |          |        |      X    |          |          |          |




 
